CREATE DATABASE Empresa_Compras

Use Empresa_Compras;
GO

CREATE TABLE Pais(
	Pais_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (50) NOT NULL
);
GO

CREATE TABLE Estado(
	Estado_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (50) NOT NULL
);
GO

CREATE TABLE Ciudad(
	Ciudad_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (50) NOT NULL,
	CodigoPostal VARCHAR (5) NOT NULL,
	EstadoId INT FOREIGN KEY REFERENCES Estado(Estado_id) NOT NULL,
);
GO

CREATE TABLE Telefono(
	Telefono_id INT PRIMARY KEY IDENTITY (1, 1),
	AreaCode VARCHAR (3) NOT NULL,
	Numero VARCHAR (7) NOT NULL,
);
GO

CREATE TABLE Cliente(
	Cliente_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre_Usuario NVARCHAR (100) NOT NULL,
	Apellido NVARCHAR (100) NOT NULL,
	Calle NVARCHAR (100) NOT NULL,
	Ciudad_id INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
	LimiteCredito decimal
);
GO

CREATE TABLE TelefonoCliente(
	Cliente_id INT FOREIGN KEY REFERENCES Cliente(Cliente_id) NOT NULL,
	Telefono_id INT FOREIGN KEY REFERENCES Telefono(Telefono_id) NOT NULL,
	primary key (Cliente_id, Telefono_id)
);
GO

CREATE TABLE Orden(
	Orden_id INT PRIMARY KEY IDENTITY (1, 1),
	Fecha DATETIME NOT NULL,
	Total DECIMAL NOT NULL,
	Impuesto DECIMAL NOT NULL,
	Calle NVARCHAR (50) NOT NULL,
	Ciudad_id INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
);
GO

CREATE TABLE TelefonoOrden(
	Orden_id INT FOREIGN KEY REFERENCES Orden(Orden_id) NOT NULL,
	Telefono_id INT FOREIGN KEY REFERENCES Telefono(Telefono_id) NOT NULL,
	primary key (Orden_id, Telefono_id)
);
GO

CREATE TABLE Categoria(
	Categoria_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (100) NOT NULL
);
GO

CREATE TABLE Producto(
	Producto_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (100) NOT NULL,
	Descripcion NTEXT,
	Precio INT NOT NULL,
);
GO

CREATE TABLE CategoriaProducto(
	Producto_id INT FOREIGN KEY REFERENCES Producto(Producto_id) NOT NULL,
	Categoria_id INT FOREIGN KEY REFERENCES Categoria(Categoria_id) NOT NULL,
	Primary key (Producto_id, Categoria_id)
);
GO

CREATE TABLE DetalleOrden(
	Orden_id INT FOREIGN KEY REFERENCES Orden(Orden_id) NOT NULL,
	Producto_id INT FOREIGN KEY REFERENCES Producto(Producto_id) NOT NULL,
	Cantidad INT NOT NULL,
	SubTotal INT NOT NULL,
	primary key (Orden_id, Producto_id)
);
GO

CREATE TABLE Transportista(
	Transportista_id INT PRIMARY KEY IDENTITY (1, 1),
	Nombre NVARCHAR (100) NOT NULL,
	Calle NVARCHAR (50) NOT NULL,
	Ciudad_id INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
);
GO

CREATE TABLE Envio(
	Envio_id INT PRIMARY KEY IDENTITY (1, 1),
	Orden_id INT FOREIGN KEY REFERENCES Orden(Orden_id) NOT NULL,
	Cliente_id INT FOREIGN KEY REFERENCES Cliente(Cliente_id) NOT NULL,
	Trasportista_id INT FOREIGN KEY REFERENCES Transportista(Transportista_id) NOT NULL,
	Ciudad_Origen INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
	Ciudad_Destino INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
	Distancia INT NOT NULL
);
GO

CREATE TABLE Suplidor(
	Suplidor_id INT PRIMARY KEY IDENTITY (1, 1),
	NombreContacto NVARCHAR (40) NOT NULL,
	NombreSuplidor NVARCHAR (130) NOT NULL, 
	Ciudad_id INT FOREIGN KEY REFERENCES Ciudad(Ciudad_id) NOT NULL,
	Pais_id INT FOREIGN KEY REFERENCES Pais(Pais_id) NOT NULL,
	Distancia INT NOT NULL
);
GO

CREATE TABLE TelefonoSuplidor(
	Suplidor_id INT FOREIGN KEY REFERENCES Suplidor(Suplidor_id) NOT NULL,
	Telefono_id INT FOREIGN KEY REFERENCES Telefono(Telefono_id) NOT NULL,
	primary key (Suplidor_id, Telefono_id)
);
GO

CREATE TABLE SuplidorProducto(
	Suplidor_id INT FOREIGN KEY REFERENCES Suplidor(Suplidor_id) NOT NULL,
	Producto_id INT FOREIGN KEY REFERENCES Producto(Producto_id) NOT NULL,
	primary key (Suplidor_id, Producto_id)
);
GO